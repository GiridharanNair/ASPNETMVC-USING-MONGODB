﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RealEstate.Rentals
{
    public class Rental
    {
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        public string Id { get; set; }
        public string Description { get; set; }
        public int NoOfRooms { get; set; }
        public List<string> Address = new List<string>();

        public Rental()
        {

        }

        public Rental(PostRentals postRental)
        {
            Description = postRental.Description;
            NoOfRooms = postRental.NoOfRooms;
            Price = postRental.Price;
            Address = (postRental.Address ??string.Empty).Split('\n').ToList();   
        }

        [BsonRepresentation(MongoDB.Bson.BsonType.Double)]
        public decimal Price { get; set; }
    }
}