﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RealEstate.Rentals;
using RealEstate.App_Start;
using MongoDB.Bson;
using MongoDB.Driver.Builders;

namespace RealEstate.Controllers
{
    public class RentalsController : Controller
    {

        public readonly RealEstateMongoContext context = new RealEstateMongoContext();
        public ActionResult Post()
        {
            ViewBag.Message = "Your Insert Page";
            return View();
        }

        public ActionResult Index()
        {
            var rentals = context.Rentals.FindAll();
            return View(rentals);
        }


        public ActionResult IndexNew(RentalsFilter filters)
        {
            var rentals = GetRentals(filters)
                .SetSortOrder(SortBy<Rental>.Ascending(r=> r.Price));
            var finalModel = new RentalsList
            {
                Rentals=rentals,
                RentalsFilter=filters
            };
            List<Rental> objects = new List<Rental>();
            objects.AddRange(rentals);
            return View(finalModel);
        }

        private MongoDB.Driver.MongoCursor<Rental> GetRentals(RentalsFilter filter)
        {
            if(!filter.PriceLimit.HasValue)
            return context.Rentals.FindAll();
            var query = Query<Rental>.LTE(r => r.Price, filter.PriceLimit);
            return context.Rentals.Find(query);
        }

        [HttpPost]
        public ActionResult Post(PostRentals postRental)
        {
            var rental = new Rental(postRental);
            context.Rentals.Insert(rental);
            return RedirectToAction("IndexNew");
            //return View();
        }

        public ActionResult AdjustPrice(string Id)
        {
            var rental = context.Rentals.FindOneById(new ObjectId(Id));
            return View(rental);
        }

        public ActionResult Delete(string Id)
        {
            context.Rentals.Remove(Query.EQ("_id", new ObjectId(Id)));
            return RedirectToAction("IndexNew");
        }



        // GET: Rentals/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Rentals/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Rentals/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Rentals/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Rentals/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //// GET: Rentals/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //// POST: Rentals/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}
