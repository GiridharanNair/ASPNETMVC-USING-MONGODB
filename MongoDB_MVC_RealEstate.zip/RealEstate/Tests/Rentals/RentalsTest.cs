﻿using MongoDB.Bson;
using NUnit.Framework;
using RealEstate.Rentals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests.Rentals
{
    class RentalsTest:AssertionHelper
    {
        [Test]
        public void ToDocument_Rentals_Price()
        {
            var rental = new Rental();
            rental.Price = 1;
            var document = rental.ToBsonDocument();
            Expect(document["Price"].BsonType,Is.EqualTo(BsonType.Double));

        }

    }
}
