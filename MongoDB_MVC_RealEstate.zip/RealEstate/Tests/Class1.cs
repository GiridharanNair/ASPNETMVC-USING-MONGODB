﻿using MongoDB.Bson;
using MongoDB.Bson.IO;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests
{
    public class BsonDocumentTests
    {
        public BsonDocumentTests()
        {
            JsonWriterSettings.Defaults.Indent = true;
        }
        [Test]
        public void EmptyDocument()
        {
            var document = new BsonDocument();
            Console.WriteLine(document.ToJson());
        }

        [Test]
        public void AddElements()
        {
            var person = new BsonDocument {
                {"age", new BsonInt32(27) },
                {"Sex", new BsonString("M") }
            };
            person.Add("firstName", new BsonString("bob"));
            Console.WriteLine(person);
        }


        [Test]
        public void AddToArray()
        {
            var person = new BsonDocument();
            person.Add("address", new BsonArray(new[] { "7815 McCallum Blvd.", "Apt# 17106","Dallas, TX" }));
            Console.WriteLine(person);
        }


        [Test]
        public void EmbedDocuments()
        {
            var person = new BsonDocument();
            person.Add("address", new BsonDocument { { "Streetline1", new BsonString("7815 McCallum Blvd")},
                {"ZipCode","75252" }
            });
            Console.WriteLine(person);
        }

    }
}
